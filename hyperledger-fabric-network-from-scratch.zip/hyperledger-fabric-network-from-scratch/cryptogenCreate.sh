if [ ! -f $GOPATH/bin/cryptogen ]; then
    go get github.com/hyperledger/fabric/common/tools/cryptogen
fi

echo
    echo "##########################################################"
    echo "##### Generate certificates using cryptogen tool #########"
    echo "##########################################################"
    if [ -d ./crypto-config ]; then
            rm -rf ./crypto-config
    fi

$GOPATH/bin/cryptogen generate --config=./crypto-config.yaml
echo


export FABRIC_CFG_PATH=$PWD


if [ ! -d ./channel-artifacts ]; then
            mkdir channel-artifacts
    fi

    if [ ! -f $GOPATH/bin/configtxgen ]; then
    go get github.com/hyperledger/fabric/common/tools/configtxgen Raft -channelID mychannel -outputBlock
    ./channel-artifacts/genesis.block 
fi