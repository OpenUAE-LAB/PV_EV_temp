if [ ! -d ./channel-artifacts ]; then
            mkdir channel-artifacts
    fi

    if [ ! -f $GOPATH/bin/configtxgen ]; then
    go get github.com/hyperledger/fabric/common/tools/configtxgen Raft -channelID mychannel -outputBlock
fi


$GOPATH/bin/configtxgen -profile Raft -channelID workspace-sys-channel -outputBlock 
./channel-artifacts/genesis.block




if [ ! -d ./channel-artifacts ]; then
            mkdir channel-artifacts
    fi

    if [ ! -f $GOPATH/bin/configtxgen ]; then
    go get github.com/hyperledger/fabric/common/tools/configtxgen
fi

echo
    echo "#################################################################"
    echo "### Generating channel configuration transaction              ###"
    echo "#################################################################"

$GOPATH/bin/configtxgen -profile TwoOrgsOrdererGenesis -outputBlock ./channel-artifacts/genesis.block -channelID "mychannel"